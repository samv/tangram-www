#-------------- slide example --------------
package User;
use base qw(Class::Tangram);
our $fields = {
        string => {
            name => {
                required => 1,
            },
            gcos => undef,
            passwd => undef,
        },
        int => {
            uid => undef,
        },
        ref => {
            group => {
                class => Group,
            },
        },
        set => {
            sec_groups => {
                class => Group,
            },
        },
    };

package Group;
use base qw(Class::Tangram);
our $fields = {
        string => {
            name => undef,
            passwd => undef,
        },
        int => {
            gid => undef,
        },
    };
#-------------- slide example ends --------------

package main;
use Tangram 2.05;
use Tangram::Relational;
use Tangram::Set;
use Tangram::Scalar;
use Tangram::Ref;
use Tangram::Schema;

my $schema = Tangram::Schema->new
	( classes => [ map { $_ => { fields => ${"${_}::fields"} } }
	               qw(User Group) ],
	  # Hmm, database doesn't like a column/table name of "group"
	  # :-)
	  normalize => sub { local($_)=shift;
			     print "$_\n";
			     s/group/ggroup/i;
			     return $_ } );

# set to -pPasswd if required
$mysqlroot = "";

# create and connect to a database - replace with non-mysql commands
# if you don't use mysql.
system("yes | mysqladmin -uroot $mysqlroot drop svtestdb");
system("mysqladmin -uroot $mysqlroot create svtestdb");
system("echo 'delete from user where User = \"svtestdb\"; "
	."grant all privileges on svtestdb.* to "
	."svtestdb\@localhost identified by \"svtestdb\";' | "
	."mysql -uroot $mysqlroot mysql");
my @dsn = ("dbi:mysql:database=svtestdb", "svtestdb", "svtestdb");

$Tangram::TRACE = \*STDOUT;
Tangram::Relational->deploy($schema, @dsn);

BEGIN { $INC{"User.pm"} = $0; $INC{"Group.pm"} = $0; }
#-------------- slide example --------------
use User;
use Group;

eval { User->new() }; # exception - no name

my $group = Group->new
    ( name => "users",
      passwd => "*" );

eval { $group->set_gid("one") }; # not int!

my $user = User->new
    ( name => "sv",
      passwd => crypt("passw0rd", "x2"),
      gcos => "Sam Vilain",
      uid => 1000 + int(rand(2000)),
      group => $group );

print $user->group->name;  # prints users
#-------------- slide example pauses --------------

$group->set_gid(1000);
$user->set_uid(1042);

my $storage = Tangram::Storage->connect($schema, @dsn);

$storage->insert($user);
my @groups;
$storage->insert(@groups = 
		 (Group->new(gid => 1001,
			    name => "games",
			    passwd => crypt("letmein", "le")),
		  Group->new(gid => 1002,
			    name => "staff",
			    passwd => crypt("staff", "st")),
		 ),
		);
$storage->insert(User->new(name => "ac",
			   uid => "1043",
			   gcos => "Alice Cooper",
			   group => $group,
			   passwd => crypt("chains", "ch")));

#-------------- slide example resumes --------------
$user->sec_groups_insert(@groups);
#-------------- slide example ends --------------


$storage->update($user);

# now tables will be in same state as slide!

$storage->disconnect();

print "Database is now in state of slide!  Press enter to clear: ";
my $junk = <>;
Tangram::Relational->retreat($schema, @dsn);
