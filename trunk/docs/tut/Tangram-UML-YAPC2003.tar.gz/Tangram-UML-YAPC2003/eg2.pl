
package File;
use base qw(Class::Tangram);
our $schema =
    {
     fields => {
		string => [ qw(name) ],
		int => [ qw(inode size) ],
		transient => { parent => undef },
	       },
    };

package Directory;
use base qw(File);
our $schema =
    {
     bases => [ qw(File) ],
     fields => {
         iarray => {
	     entries => { class => "File",
			  back => "parent",
			},
         },
         int => {
             hash_seed => {
			   init_default => sub {
			       int(rand(2**31));
			   }
	     },
         },
     },
    };

package main;
use Tangram 2.05;
use Tangram::Relational;
use Tangram::IntrArray;
use Tangram::Scalar;
use Tangram::Schema;

# set to -pPasswd if required
$mysqlroot = "";

# re-use the database from the last example
my @dsn = ("dbi:mysql:database=svtestdb", "svtestdb", "svtestdb");

# Show what Tangram is doing
$Tangram::TRACE = \*STDOUT;

#=====================================================================
#  Standard "Vertical" table mapping
#=====================================================================
Class::Tangram::import_schema($_) foreach qw(File Directory);
my $schema = Tangram::Schema->new
	( classes => [ map { $_ => ${"${_}::schema"} }
	               qw(File Directory) ] );

Tangram::Relational->deploy($schema, @dsn);

{
    my $storage = Tangram::Relational->connect($schema, @dsn);

    my $dir;
    $storage->insert($dir = Directory->new(name => "/",
				       inode => 1,
				       size => 4096));

    # This more "Message Passing" version works with Class::Tangram 1.50test1
    # $dir->entries_insert
    push @{ $dir->entries }, 
	(
	 File->new( name => "vmlinuz",
		    inode => 2,
		    size => 1235220    ),
	 Directory->new( name => "etc",
			 inode => 3,
			 size => 4096,
			 entries => [
				     File->new( name => "rc",
						inode => "4",
						size => 3420 )
				    ]
		       ),
	);

    $storage->update($dir);
    $storage->disconnect();
}

# Demonstrate back-references
{
    my $storage = Tangram::Relational->connect($schema, @dsn);

    my $remote_file = $storage->remote("File");
    my ($file) = $storage->select
	(
	 $remote_file,
	 $remote_file->{name} == "rc"
	);

    while ($file->parent) {
	$file = $file->parent;
    }

    print "The root directory is ".$file->name."\n";

}

print("Database is now in state of slide (horizontal mapping)!\n"
      ."Press enter to clear: ");
my $junk = <>;
Tangram::Relational->retreat($schema, @dsn);

#=====================================================================
#  "Horizontal" table mapping
#=====================================================================

# The following line is what makes the difference:
$Directory::schema->{table} = "File";

my $schema = Tangram::Schema->new
	( classes => [ map { $_ => ${"${_}::schema"} }
	               qw(File Directory) ] );

Tangram::Relational->deploy($schema, @dsn);

{
    my $storage = Tangram::Relational->connect($schema, @dsn);

    my $dir;
    $storage->insert($dir = Directory->new(name => "/",
				       inode => 1,
				       size => 4096));

    # $dir->entries_insert
    push @{ $dir->entries }, 
	(
	 File->new( name => "vmlinuz",
		    inode => 2,
		    size => 1235220    ),
	 Directory->new( name => "etc",
			 inode => 3,
			 size => 4096,
			 entries => [
				     File->new( name => "rc",
						inode => "4",
						size => 3420 )
				    ]
		       ),
	);

    $storage->update($dir);
    $storage->disconnect();
}

# Demonstrate back-references
{
    my $storage = Tangram::Relational->connect($schema, @dsn);

    my $remote_file = $storage->remote("File");
    my ($file) = $storage->select
	(
	 $remote_file,
	 $remote_file->{name} == "rc"
	);

    while ($file->parent) {
	$file = $file->parent;
    }

    print "The root directory is ".$file->name."\n";

}

print("Database is now in state of slide (vertical mapping)!\n"
      ."Press enter to clear: ");
my $junk = <>;
Tangram::Relational->retreat($schema, @dsn);

