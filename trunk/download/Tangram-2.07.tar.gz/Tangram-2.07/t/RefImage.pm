package Tangram::RefImage;
use base qw(Tangram::Ref);
$Tangram::Schema::TYPES{ref_image} = Tangram::RefImage->new();

