# (c) Sound Object Logic 2000-2001

# just for compatibility: functionality is now loaded on demand via SelfLoader

1;
