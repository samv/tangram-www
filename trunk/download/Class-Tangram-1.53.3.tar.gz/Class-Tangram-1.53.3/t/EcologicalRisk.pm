
package EcologicalRisk;

# example package file that defines some extra subs

sub set_curies {
    my $self = shift;

    $self->SUPER::set_curies(42);
}

1;
