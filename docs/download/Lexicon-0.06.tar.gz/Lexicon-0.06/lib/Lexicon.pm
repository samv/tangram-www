#!/usr/bin/perl -w

package Lexicon;

use strict;# is my bitch
use Carp;

# package globals
use vars qw($VERSION @conf_files $CONFIG $CONFIG_FILENAME
	    $DEBUG @inherited $RETRY_MAX);

use Pod::Constants
    'MODULE RELEASE' => sub { ($VERSION) = m/(\d+\.\d+)/ },
    'CONFIGURATION' => sub { @conf_files = m/`([^']*)'/g },
    'DEFAULT CONFIG FILE' => sub { ($CONFIG = $_) =~ s/^ //gm; },
    'do_or_die($coderef)' => sub { ($RETRY_MAX) = m/(\d+)/ },
    'LIST OF INHERITED FUNCTIONS' => sub { @inherited = m/(\w+)/g };

BEGIN {
    # For debugging this module, set this to 1
    $DEBUG = 0;

    if ($DEBUG) {
	eval 'sub mutter { print STDERR "Lexicon: <D> @_\n" };';
    } else {
	eval 'sub mutter { }';
    }

    sub say { print STDERR "Lexicon:  @_\n" };
};


=head1 NAME

Lexicon - Run-time L10N from a database for perl programs

=head1 SYNOPSIS

 # OO usage
 use Lexicon;

 # "whence" is an optional label for this script, for later
 # association of Lexicon entries with their usage.
 # "lang" is the language you would like entries to come OUT of the
 # lexicon in.
 my $lexicon = Lexicon->open ( whence => "script",
                               lang => "fr" );

 # search for an entry for the word "cheese" and print it out
 print $lexicon->lookup("cheese");

 # search for an entry with name => "_tag123"
 print $lexicon->lookup('_tag123');

 # The "_" function now defaults to looking up in the lexicon for "fr"
 # translations
 print _("Hello");    # should print "Bonjour"

 # tied object usage
 tie %tag, "Lexicon", whence => "script", lang => "fr";

 print $tag{tag123};   # same as ->lookup('_tag123');

 #----- USAGE 1 -----
 # To include Lexicon entries in a page
 use Lexicon::Entry::en _ => ( group => "local" );

 # Objects returned by _($name, @args) are now
 # Lexicon::Entry::en objects.

 $lexicon->lookup($obj)->text(@args);

=head1 DESCRIPTION

This package implements a "Lexicon" - that is, a database of phrases
to their corresponding translations in other languages.

This allows you to internationalise your programs (assuming you can
have a Tangram storage back-end available at run time; patches for
other storage means will be gladly accepted).  In fact, you can often
save yourself the tedious task of getting grammar correct in messages
that your programs emit ("found 1 file(s)" type messages).

The core of the Lexicon is the Lexicon::Entry - lookups are specified
in terms of lexicon entries, and are returned as entries.

The first time you "use Lexicon", it will write a configuration file
to F<~/.lexicon>.  Check it out, edit it and if necessary save as
F</etc/lexicon.conf>

=head1 DEPENDENCIES

This module is dependent on:

 Module name                    Version
 -----------                    -------
 Pod::Constants                => 0.12
 Class::Tangram                => 1.12
 Date::Manip                   => 5.21
 I18N::LangTags                => 0.26
 Lingua::EN::Numbers           => 0.01
 Lingua::EN::Numbers::Ordinate => 0.01

=head1 MODULE RELEASE

This is Lexicon version 0.06

=cut

use I18N::LangTags qw(is_language_tag super_languages
		      same_language_tag similarity_language_tag
		      locale2language_tag);

use Lexicon::UniqueObject;
use vars qw(@ISA $schema);
@ISA = qw(Lexicon::UniqueObject);

$schema =
    {
     table => "Lexicon",
     id => 1,
     fields =>
     {
      transient =>
      {
       storage => {
	       check_func => sub {
		   my $value_r = shift;
		   die("dbh must be a Tangram::Storage object, not a "
		       .(ref $$value_r||$$value_r))
		       unless UNIVERSAL::isa($$value_r,
					     "Tangram::Storage");
	       },
	      },
       map { $_ => undef }

       (qw[tangram_backend tangram_schema dbd dbi_db
	   dbi_host dbi_user dbi_pass dbi_port auto_deploy
	   auto_vivify auto_translate lang])

      },
      # auto-updated fields
      int => [ qw(open_count lookup_count) ],

      ref =>
      {
       whence => {
		  class => "Lexicon::Group",
		  },
      },
     },
    };

use DBI;
use Lexicon::Schema;

use Tangram;
use Tangram::Ref;
use Tangram::Scalar;

=head1 GLOBALS

There is a Perl instance global in $Lexicon::Default.  This is the
Default Lexicon for Lexicon::Entry's.

Therefore, after a Lexicon has been loaded, any new Lexicon::Entry's
created will be loaded from the Lexicon in preference of being freshly
created.

I haven't put much thought presently to how this integrates with
applications that will supply their lexicon files in purely Perl
format; expect possibly large changes to syntax over the next few
versions of this module to cope with this.

Use the Lexicon->Default() function to return the default Lexicon.

=cut

use vars qw($Default);
sub Default {
    return ($Default ||= do {
	die "Auto-lexicon opening disabled";
	mutter "Lexicon: Auto-creating default Lexicon";
	$_[0]->open();
    });
};

sub _obj {
    my $invocant = shift || __PACKAGE__;

    if ( ref $invocant and UNIVERSAL::isa($invocant, __PACKAGE__ ) ) {
	return $invocant;
    } else {
	return $invocant->Default;
    }
}

sub dsn {
    my $self = _obj(shift);
    return (
	    ( "dbi:$self->{dbd}:".
	     ($self->{dbi_host} ? "host=$self->{dbi_host};" : "")
	     . "database=$self->{dbi_db}"
	     . ( $self->{dbi_port} ? ";port=$self->{dbi_port}" : "" ) ),
	    $self->{dbi_user},
	    $self->{dbi_pass}
	   );
}

# override get and set so that they are _obj()'ified
sub set {
    my $self = _obj(shift);
    $self->SUPER::set(@_);
}

sub get {
    my $self = _obj(shift);
    $self->SUPER::get(@_);
}

=head1 INHERITED STORAGE INTERFACE

The Lexicon class provides all of the important functions
that Tangram::Storage does, via a servant class.  The exact
functions that are allowed through are listed below.

This means you can do things like Lexicon->insert($obj),
etc.

=head2 LIST OF INHERITED FUNCTIONS

load select id insert update erase remote cursor tx_do
tx_start tx_commit tx_rollback unload disconnect

=cut

sub _storage {
    my $func = shift;
    my $self = _obj(shift);
    if ( UNIVERSAL::isa($self->{storage}, "Tangram::Storage") ) {
	$self->{storage}->$func(@_);
    } else {
	die "not called as method, or storage not open!";
    }
}

BEGIN {
    mutter "creating functions (@inherited)";
    do { 
	eval "sub $_ { unshift \@_, '$_'; goto &_storage }";
    } foreach (@inherited);
};

=head1 CONFIGURATION

The configuration file for Lexicon.pm is at one of the
following locations: `/etc/lexicon.conf' or `~/.lexicon'.
It is a piece of perl code which is called with "no strict"
and with $self in scope.

=head2 DEFAULT CONFIG FILE

 #   Lexicon.pm configuration file
 #
 # Backend: the storage backend to use.  Tangram
 $self->{tangram_backend} = Tangram::mysql;

 # DBI backend
 $self->{dbd} = mysql;

 #  Database, username & password, etc.
 $self->{dbi_db} = "lexicon";
 $self->{dbi_user} = "lexicon";
 $self->{dbi_pass} = "7003l1t34u";
 # $self->{dbi_host} = "lexicon";
 # $self->{dbi_port} = 3306;  # mysql's default

 # Right.  So, with the defaults there, you'd do this to
 # set up the corresponding database:

 # mysql -uroot -p
 # mysql> create database lexicon;
 # mysql> grant all privileges on lexicon.* to \
 #          lexicon@localhost \
 #          identified by "7003l1t34u";
 # mysql> flush privileges;
 # mysql> exit
 #
 # Now, roll out a lexicon database to it with
 # "Lexicon->deploy" (you can safely omit this step if you
 # leave automatic deployment on, below):
 #
 # hoffman:~$ perl -MLexicon -e 'Lexicon->deploy'
 # hoffman:~$ perl -MLexicon -e 'Lexicon->shell'

 # Schema setup.  Start with a clean plate.
 Lexicon::Schema->zap_schema;

 # classes to go into the Lexicon schema; order and position
 # in the list is important!  Tangram assigns a type
 # identifier to each element in this list, so add extra
 # classes AFTER the call to add_languages, below, or you'll
 # have non-trivial data migration to do.

 Lexicon::Schema->add_classes
    (qw(Lexicon::UniqueObject Lexicon::NamedObject
       Lexicon Lexicon::Group
       Lexicon::Entry Lexicon::Entry::Latin));

 # languages to go into the Lexicon schema
 Lexicon::Schema->add_languages qw(en fr);

 $self->{tangram_schema} = Lexicon::Schema::schema;

 # Turn on automatic deployment of the Lexicon database if
 # it is not found.
 $self->{auto_deploy} = 1;

 # Turn on auto-vivication of Lexicon entries - that is, if
 # you request an entry that doesn't exist, it will be
 # created on demand.
 # $self->{auto_vivify} = 1;

 # Turn on auto-translation via Lingua::Translate of unknown
 # entries
 # $self->{auto_translate} = 1;

 # for automatic translation; configure Lingua::Translate.
 #use Lingua::Translate;
 #Lingua::Translate::config( back_end => SysTran,
 #                           host => "babelfish"  );

=head2 Lexicon::LoadConfig($filename)

This routine loads the config file from disk.

=cut

sub LoadConfig {
    my $filename = shift;

    if ( CORE::open CONFIG, "<$filename" ) {
	mutter "loading config file $filename";
	local $/ = undef;
	$CONFIG = <CONFIG>;
	$CONFIG_FILENAME = $filename;
	close CONFIG;
    }
}

=head2 Lexicon::CreateConfig($filename)

This routine opens $filename and writes out the contents of
the last loaded config file to it.  If no config file has
been loaded yet, it will make the contents the default,
above.

=cut

sub CreateConfig {
    my $filename = shift;

    CORE::open ">$filename" or return undef;
    print $filename $CONFIG;
    chmod 0644, $filename;
    chown 0, 0, $filename;
    close $filename;

    say "Config file `$filename' generated.  Look at it!";
    return 1;
}

=head2 Lexicon->deploy([$dbh])

Deploys to a database handle or the configured database
location.

=cut

sub deploy {
    my $invocant = shift;

    my $schema = Lexicon::Schema->schema;

    my $dbh = shift || DBI->connect($invocant->dsn)
	or die "Could not connect to database; $DBI::errstr";
    mutter "Deploying $invocant to $dbh";

    my $back_end = $invocant->tangram_backend;

    eval "use $back_end";
    die "$@ loading storage back-end `$back_end'" if $@;

    $back_end->deploy($schema, $dbh)
	or die "Some error (`$DBI::errstr'?) deploying database";
}

=head2 Lexicon->print_schema

This routine takes the SQL schema that would be used to
deploy the database with ->deploy and prints it to STDOUT
(or whichever filehandle is currently selected).

=cut

sub print_schema {
    my $invocant = shift;

    my $schema = Lexicon::Schema->schema;
    $invocant->backend->deploy($schema);

}

sub shell {
    print "Heh, yeah right.\n";
}

=head1 CONSTRUCTORS

=head2 new(attribute => $value[, ...]) : Lexicon

This function creates a new Lexicon object, but does not try
to connect to the database.

It takes initialisation options as attribute => value pairs.
The contents of the config file are first eval'd, then any
construction options are passed to the ->set() function.

=over

=item lang

The desired language for retrieval of lexicon entries.

=item whence

Who are you, and why do you want translations? Either a
Lexicon::Group object, or the name of one.  The group is
automatically ratify()'ed on open.

=item storage

A Tangram::Storage object.  In normal operation you wouldn't
supply this.  It's mentioned here for completeness' sake.

=item tangram_backend

A class name for the Tangram backend to use.  Something like
Tangram::Relational or Tangram::mysql.

=item tangram_schema

The Tangram::Schema object that represents this store.

=item dbd

The DBI backend to use, in the form given to DBI.

=item dbi_db

The database name name for the DBI connection

=item dbi_host

The host name for the DBI connection

=item dbi_user

The username for the DBI connection

=item dbi_pass

The password for the DBI connection

=item dbi_port

The port number for the DBI connection

=item auto_deploy

If the database connection attempt fails, then it assumes it
was because the database has not been created, and attempts
to run Tangram::Relational->deploy on it.

=item auto_vivify

If set and a lexicon lookup fails, then a new entry is
created and the system pretends nothing happened.

=item auto_translate

If set and a lexicon lookup fails, but an entry is available
in another language, then automatic translation is
attempted.  This requires that Lingua::Translate is
configured properly.

=back

=cut

sub new {
    my $invocant = shift;
    my $self;

    # the "copy" constructor: $instance->new()
    if ( ref $invocant ) {
	$self = bless {%$invocant}, ref $invocant;
    } else {
	$self = bless {}, $invocant;
    }

    {
	no strict;
	local ($^W) = 0;
	eval $CONFIG;
	die "Error processing config file ($CONFIG_FILENAME): `$@'"
	    if $@;
    }

    $self->set(@_);

    # guess the language if not supplied
    $self->{lang} ||= ( $ENV{HTTP_ACCEPT_LANGUAGE}
			|| locale2language_tag($ENV{LANG})
			|| "en" );

    return $self;
}

=head2 open

Connects to the Lexicon and returns a Lexicon object.  If the
connection attempt fails, an exception is thrown.  Arguments are the
same as for "new", above.

If C<auto_deploy> is set, then an attempt to deploy the database
structure is made.

=cut

sub open {
    my $class = shift;

    croak "must have an even number of arguments"
	if (scalar(@_) & 1);

    # call the Class::Tangram constructor
    my ($self) = $class->new(@_);

    eval {$self->connect("aye")};
    if ( $@ ) {
	if ( $self->{auto_deploy} ) {
	    # could not connect; perhaps the DB is not deployed?

	    mutter "Tangram failed to load; attempting deploy";
	    my $dbh = DBI->connect_cached($self->dsn);
	    $self->deploy ($dbh);
	    mutter "Re-starting Tangram";
	    $self->connect();
	} else {
	    die $@;
	}
    }

    # make whence sensible
    ($self->{whence} = $0) =~ s!.*/!!
	unless ( $self->{whence} );

    # ratify self
    $self = $self->ratify($self);
    $self->{open_count}++;
    $self->{storage}->update($self);

    # First lexicon opened stays the default; set the
    # language with Lexicon->Default->set_lang("")
    $Default ||= $self;

    return $self;

}

=head1 methods

=head2 connect() : undef

Takes the current password, host, etc, and tries to connect to the
Lexicon.  Does not auto-deploy (see open, above).  Dies on failure.

=cut

sub connect {
    my $self = shift;
    my $dtrt = shift;
    UNIVERSAL::isa($self, "Lexicon")
	    or croak "connect must be called as method";

    mutter "Opening DBI handle";
    # open a DBI handle
    my $dbh = DBI->connect_cached($self->dsn)
	or die "DB connect failed; $DBI::errstr";
    mutter "DB connected OK";

    # connect to the database
    my $open_tangram = 1;
    if ( $dtrt ) {
	local $dbh->{PrintError} = 0;
	my $arrayref = $dbh->selectall_arrayref("select * from Tangram");
	die "db not deployed" if (!$arrayref or @$arrayref < 1);
    }

    if ( $open_tangram ) {
	mutter "Starting Tangram";
	$self->{storage} ||= Tangram::Storage->connect
	    ( Lexicon::Schema->schema,
	      $self->dsn,
	      { dbh => $dbh } );
    }

    $self->set_lang($self->lang);

}

sub set_lang {
    my $self = _obj(shift);
    $self->{lang} = shift;

    my %x;
    %x = map { $_ => similarity_language_tag($_, $self->{lang}) }
	Lexicon::Schema->languages();

    my ($best) = (sort {$x{$b} <=> $x{$a}} keys %x);
    unless ( $x{$best}) {
	say("Could not load language for $self->{lang}; falling back"
	    . " to en");
	$best = "en";
    }
    mutter "Requested language is $self->{lang}, given is $best";
    $self->{lang} = $best;

}

=head2 get_whence : ( Lexicon::Group | scalar )

Returns the "whence" attribute of this object.  If it is currently a
scalar, fetch the appropriate Lexicon::Group out of the database, or
create a new Lexicon::Group and return that.

If storage is not open, this will return whatever "whence" is -
probably a scalar.

=cut

sub get_whence {
    my $self = shift;

    if ( $self->{storage} ) {
	if ( !UNIVERSAL::isa($self->{whence}, "Lexicon::Group")
	     or !$self->id($self->{whence}) ) {
	    $self->{whence} = $self->group();
	}
    }

    return $self->{whence};
}

=head2 set_whence($whence)

Sets the "whence" attribute of this object.  Set to either a string,
or a Lexicon::Group object.

=cut

sub set_whence {
    my $self = shift;
    my $whence = shift;

    if ( $self->{storage} ) {

	if ( !UNIVERSAL::isa($whence, "Lexicon::Group") ) {
	    $whence = $self->group($whence);
	}

	$self->{storage}->id($whence)
	    or $self->{storage}->insert($whence);

	$self->{whence} = $whence;
    } else {
	$self->{whence} = $whence;
    }

}

=head2 group($group) : Lexicon::Group

Returns the Lexicon::Group with name $group.  If $group is not
specified, uses the default, which is the current value of the
"whence" attribute.

=cut

sub group {
    my $self = shift;
    my $group = shift || $self->{whence};

    unless ( UNIVERSAL::isa($group, "Lexicon::Group") ) {
	$group = Lexicon::Group->new(name => $group);
    }

    return $self->ratify($group);
}

=head1 STORAGE RELATED FUNCTIONS

The following functions should really be moved into a seperate class
that Lexicon derives from.

=head2 do_or_die($coderef)

Executes $coderef inside tx_do inside eval {} until it works (ie,
doesn't throw an exception with die) or hits the limit of 1
execution.

=cut

sub do_or_die {
    my $self = shift;
    my $closure = shift;

    my ($success, @errors);
    for ( 1 .. $RETRY_MAX ) {
	my (@return, $return);

	if ( wantarray ) {
	    @return = eval { $self->{storage}->tx_do($closure) };
	    return @return unless $@;
	} else {
	    $return = eval { $self->{storage}->tx_do($closure) };
	    return $return unless $@;
	}
	push @errors, $@;
    }

    my $error = pop @errors;
    croak "@errors; do_or_die sub failed $RETRY_MAX times; giving up";
}

=head2 ratify($obj : Lexicon::UniqueObject) : Lexicon::UniqueObject(P)

Checks that $obj is a valid object in the database, and returns one
that is in the database if it isn't.

This function will ALWAYS insert if not found.

=cut

sub ratify {
    my $self = _obj(shift);
    my $obj = shift;
    croak "ratify requires an argument" unless $obj;
    croak "1st arg to ratify must be Lexicon::UniqueObject"
	unless (UNIVERSAL::isa(ref $obj, "Lexicon::UniqueObject"));

    my $ratified;

    if ( my $id = $self->{storage}->id($obj) ) {

	if ( $self->{_hard} ) {

	    # Re-load from DB for safety
	    $self->{storage}->unload($id);
	    $ratified = $self->{storage}->load($id);
	} else {

	    # no, don't, it's too slow.
	    $ratified = $obj;
	}


    } else {
	# select from storage or put in
	$ratified = $self->do_or_die
	    (sub {
		 my $found = $self->query($obj);
		 if ( $found ) {
		     return $found;
		 } else {
		     $self->{storage}->insert($obj);
		     return $obj;
		 };
	     });
    }

    delete $self->{_hard};

    # don't need to merge if the objects are the same
    unless ( ($obj+0) == ($ratified+0) ) {
	$ratified->merge($obj);
	#$obj->clear_refs();
    }

    return $ratified;
}

=head2 $lexicon->ratify_hard($obj : Lexicon::UniqueObject) : Lexicon::UniqueObject(P)

(pending a better name)

Ratifies $obj as above, but if $obj is already a persistent object,
dump it and re-merge what's in the DB.  Useful for putting near the
start of your tx_do operations.

=cut

sub ratify_hard {
    my $self = _obj(shift);
    $self->{_hard} = 1;
    unshift @_, $self;
    goto \&ratify;

}

=head2 $lexicon->valid_lang($lang)

returns 1 if the value passed to us is a valid lexicon language, or
undef otherwise.

=cut

sub valid_lang {
    shift if ( UNIVERSAL::isa($_[0], __PACKAGE__ ) );
    my $lang = shift;
    return scalar grep /^$lang$/i, Lexicon::Schema::languages();
}


=head2 $lexicon->query(@parms) : Lexicon::UniqueObject

This performs a select with $parms[0]->select_func(@parms[1..$#parms])
for a filter.

For instance, with Lexicon::NamedObject types, the select_func returns
a filter that will match objects with the same name (and type).

Returns undef if there are none; that is, never inserts objects into
the database if they don't exist (see ratify() for that).  Returns the
first match, or all matches if called in list context.

=cut

sub query {
    my $self = _obj(shift);
    my $meme = shift;
    croak ("1st arg must be Lexicon::UniqueObject instance or class "
	   ."name ")
	unless UNIVERSAL::isa($meme, "Lexicon::UniqueObject");

    # FIXME - objects of subclass types will replace superclasses in
    # code when they are ratified.  This might not be a problem.  Need
    # more time to consider that.
    (my @objs, @_) = $self->{storage}->select
	($meme->select_func($self->{storage}, @_));

    # FIXME - really this should compare membership of groups, too
    @objs = sort @objs;
    foreach (@objs) {
	$_->set_lexicon($self) if $_->can("set_lexicon");
    }

    if ( wantarray ) {
	return @objs
    } else {
	return shift @objs;
    }
}

=head1 CORE LEXICON FUNCTIONS

=head2 lookup($entry : Lexicon::Entry) : Lexicon::Entry

Looks up a given tag in the Lexicon and returns the translation to the
language of the Lexicon (set it with Lexicon->set_lang()).

If C<auto_vivify> is set, and the specified entry is not found in the
database, then one is inserted.

If C<auto_translate> is set, then Lingua::Translate is evoked to
perform the translation, and the result saved.

It is also possible to specify the entry as a string, which is taken
to be the name of the entry.

=cut

sub lookup {

    my $self = _obj(shift);
    croak "Lexicon::lookup: must be called as method"
	unless UNIVERSAL::isa($self, __PACKAGE__);

    my $class = "Lexicon::Entry::$self->{lang}";
    mutter "Class is $class";
    #kill 2 , $$ if $class =~ /fr/;

    # qualify the input into a lexicon entry
    my $entry = shift;
    if ( UNIVERSAL::isa(ref $entry, "Lexicon::Entry") ) {

	# an entry, but the right language?
	if ( $entry->lang ne $self->{lang} ) {

	    # no, turn object into query object
	    $entry = $class->new( name => $entry->name,
				  args => $entry->args );
	} elsif ( $self->{storage}->id($entry) ) {

	    # great, it's persistent - just give it back
	    return $entry;
	} else {
	    # not persistent - fall through to query, below
	}

    } else {
	(my $argstack, @_) = ([ @_ ]);
	$entry = $class->new( name => $entry,
			      args => $argstack );
    }

    # So, now, $entry is a Lexicon entry of the correct type, but
    # in an unknown state of persistence.

    # do the query
    my @results = $self->query($entry);

    if ( @results ) {
	# good; found.
	my $good_entry = shift @results;

	# merge in any important transient fields
	$good_entry->merge($entry);

	# record usage / insert
	$self->touch($good_entry);

	$entry = $good_entry;
    } else {

	# not found; do another query for any language
	if ( my @objs = $self->query('Lexicon::Entry' => $entry->name) )
	{
	    # ok, we got some back.  Note: these probably won't be in
	    # our language.
	    $entry = $self->babelfish($entry, @objs);

	} elsif ( $self->{auto_vivify} and $entry->name !~ /^_/) {

	    # this is a new entry.  Add to the Lexicon, and return it
	    $self->{storage}->insert($entry);
	    return $entry;

	} else {

	    # give up
	    die ("Lexicon entry `".$entry->name."' not found in "
		 ."language $self->{lang}");
	}
    }

    return $entry;
}

=head2 touch($entry, [$entry, [...]]);

Ensures that the groups stuff for C<$entry> is done

=cut

sub touch {
    my $self = _obj(shift);

    while ( my $entry = shift ) {
	#kill 2, $$;
	my $group = ( $entry->whence ?
		      $self->group($entry->whence) :
		      $self->whence );

	$self->do_or_die
	    (sub {
		 #kill 2, $$;
		 return if $group->members_includes($entry);
		 #local ($Tangram::TRACE) = \*STDOUT;
		 #print "Inserting a member into Group ".($group+0).", ";
		 #print "Entry ".($entry+0)." is ".($self->id($entry)?"":"NOT ")."persistent\n";
		 $group->members_insert($entry);
		 $self->update($group);
	     });
    }
}

=head2 babelfish($entry [,$entry [...]])

Given a list of entries, returns an entry in the language of the
current lexicon.  These should be provided in preferred order;
translation will be attempted until one succeeds if translation has
been configured (or, in fact, programmed :-)

dies if it can't do it.

=cut

sub babelfish {
    my $self = _obj(shift);
    my $original = shift;

    while ( my $entry = shift ) {
	if ( &same_language_tag($entry->lang, $self->{lang}) ) {
	    return $entry;
	} elsif ( $self->{auto_translate} ) {

	    # whew!  This is a more difficult task than I thought

	    # If the entry is "flat":
	    #    1. pass to Lingua::Translate
            #    2. add translated entry to the Lexicon

            # If the entry isn't "flat":
	    #    1. flatten, and create a new entry marked as temp
            #    2. pass to Lingua::Translate
	    #    3. add temp entry to the Lexicon

	    # problem: can't flatten without @args

	    die "Auto-translation not coded yet";

	}
    }

    die ("Cannot find translation for entry `".$original->name
	 ."' and automatic translation not written yet");
}


BEGIN {
    $| =1;
    mutter "Innit tho!";

    s!^~!$ENV{HOME}!e foreach (@conf_files);
    my ($system, $user) = (@conf_files);

    if ( -f $user ) {
	# per-user configuration - load it if possible
	mutter "Loading configuration from $user";
	LoadConfig($user);

    } elsif ( -f $system ) {
	# system configuration - load it
	mutter "Loading configuration from $system";
	LoadConfig($system);

    } elsif ( CORE::open DEFAULT, ">$user" ) {
	chmod 0644, $user;
	chown 0, 0, $user;
	print DEFAULT $CONFIG;
	close DEFAULT;
	say "default config file `$user' written";
    }

};

=head2 TIEHASH

This will tie a hash to a lexicon lookup.  Usage:

  tie %tag, 'Lexicon';

This will create a new lexicon handle; arguments to the
constructor should be listed after 'Lexicon'.  If you want
to re-use an existing handle, you have two options:

  tie %tag, 'Lexicon', $lexicon;

Or, if you want to just re-use the database handle:

  tie %tag, 'Lexicon', lang => "de";

($lexicon in these examples are already-existing Lexicon
objects)

Untested.

=cut

sub TIEHASH {
    my $class = shift;

    my $self;

    # allow the first parameter to be an existing lexicon handle
    if ( UNIVERSAL::isa($_[0], __PACKAGE__) ) {
	$self = shift;
	bless $self, $class;
    } else {
	$self = $class->open(@_);
    }

    return $self;
}

=head2 FETCH

Returns the entry looked up in the lexicon.

=cut

sub FETCH {
    my $self = shift;
    (my $entry = shift) =~ s/^/_/;
    $self->lookup($entry);
}

=head2 close

Finish off a Lexicon connection

=cut

sub close {
    my $self = shift;

    if ( my $storage = delete $self->{storage} ) {
	$storage->disconnect();
    }
}

sub DESTROY { goto &close }

=head1 Lexicon::UniqueObject methods

The following methods are inherited/overridden from
Lexicon::UniqueObject.

=head2 $lexicon1->merge($lexicon2)

Takes two lexicon objects and puts the best of both into $lexicon1

=cut

sub merge {
    my $self = shift;
    my $obj = shift;

    while ( my ($key, $value) = each %$obj ) {
	$self->{$key} ||= $value;
    }
    # max of lookup count, etc
    for my $field (qw(open_count lookup_count)) {
	local ($^W) = 0;
	$self->{$field} = $obj->{$field}
	    if ( $self->{$field} < $obj->{$field} )
    }
    $self->set_lang($obj->{lang});

    # don't let a dup. handle get disconnected!
    my $storage = delete $obj->{storage};
    $self->{storage} ||= $storage;
}

=head2 $lexicon->select_func($storage[, $whence])

See L<Lexicon::UniqueObject>

=cut

sub select_func {
    my $self = shift;
    my $storage = shift;
    my $whence = shift || $self->whence || croak "need whence";

    local ($self->{storage}) = $storage;
    $whence = $self->ratify($whence, "Lexicon::Group");

    my $julie = $storage->remote(__PACKAGE__);

    return ( $julie,
	     $julie->{whence} eq $whence );

}

=head2 size

Returns the total number of Lexicon::Entry objects in the database

=cut

sub size {
    my $self = shift;

    # Dammit, sometimes it's just easier to do it with SQL :)
    my $query = "select count(*) from "
	.$Lexicon::Entry::schema->{table};

    my $sth = $self->{storage}->{db}->prepare($query)
	or die $DBI::errstr;
    $sth->execute() or die $DBI::errstr;

    my $answer = $sth->fetchrow_hashref();

    return $answer->{'count(*)'};

}

=head1 FILES

=over

=item F<~/.lexicon>

=item F</etc/lexicon.conf>

Configuration files - see the section on "CONFIGURATION FILES", above.

=back

=head1 BUGS/TODO

No knowledge of character sets!

auto_vivify may occasionally automatically vivify entries into the
wrong language; investigation pending.  Perhaps entries should have
specified the language of their name.

=head1 AUTHOR

Sam Vilain <sv@easyspace.com>

=head1 SEE ALSO

L<Lexicon::Entry>, L<Lexicon::Schema>

=cut

42;
