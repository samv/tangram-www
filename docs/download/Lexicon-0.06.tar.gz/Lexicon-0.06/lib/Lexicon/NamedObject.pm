#!/usr/bin/perl -w

package Lexicon::NamedObject;

use strict;
use Carp;

=head1 NAME

Lexicon::NamedObject - Unique objects where the name/class combination is the key

=head1 SYNOPSIS

 # programming NamedObject derived types:
 package Lexicon::SomeThing
 use base qw(Lexicon::NamedObject);

 $schema = { fields => { ... },
             bases => [qw[Lexicon::UniqueObject]] };

 # Using NamedObject derived types:
 my $foo = Lexicon::SomeThing->new(name => "SomeName");

 # query - search only, never insert
 $foo = Lexicon->query($foo);

 # like query, but inserts if not found.
 $foo = Lexicon->ratify($foo);

=head1 DESCRIPTION

NamedObject is an example UniqueObject, where there is a single unique
identification for the object, and that key called "name".

=cut

use Lexicon::UniqueObject;
use vars qw($schema @ISA);
@ISA = qw(Lexicon::UniqueObject);

$schema =
{
 bases => [ qw(Lexicon::UniqueObject) ],
 fields =>
 {
  string => [ qw(name) ],
 },
 table => "symbols",
 id => 3,
};


=head1 FUNCTIONS

=head2 $self->merge($new_obj)

Take any interesting information out of the object $new_obj
(presumably a non-persistent object) and write it into $self

This function does nothing; you will have to override it if you want
more intelligent behaviour.

=cut

sub merge {
    my $self = shift;
    my $obj = shift;
    $self->SUPER::merge($obj);

    croak ("Attempt to merge ".(ref $self)." `$self->{name}' "
	   ."with ".(ref $obj)." `$obj->{name}'")
	unless ( $self->{name} eq $obj->{name});

    # don't attempt to merge anything; the subclass method will do
    # that.
}

=head2 $self->select_func($storage[, $name])

Returns a Tangram select expression that will match this object in
storage.  If $name is given, then the returned select function will be
for the name you gave it.  When called as a class method, you must
specify the name.

Return:

   1 - a Tangram::Remote object
   2 - Tangram Filter

=cut

sub select_func {
    my $invocant = shift;
    my $storage = shift;
    my $name = shift;
    croak "invocant not ".__PACKAGE__
	unless UNIVERSAL::isa($invocant,__PACKAGE__);
    croak "1st arg not Tangram::Storage"
	unless UNIVERSAL::isa($storage,"Tangram::Storage");
    croak "must be given a name"
	if ( !$name and !ref $invocant );
    $name ||= $invocant->{name};

    my $class = ref $invocant || $invocant;

    my $schizoid_other_self = $storage->remote($class)
	or die "$class is not a valid storage class";

    return ( $schizoid_other_self,
	     $schizoid_other_self->{name} eq $name );
}

"This is the" __END__, my only friend.

=head1 SEE ALSO

L<Tangram::Storage>, L<Lexicon>

=cut
