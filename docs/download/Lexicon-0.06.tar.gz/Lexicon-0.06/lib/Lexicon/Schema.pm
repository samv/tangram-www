#!/usr/bin/perl -w

use strict;

package Lexicon::Schema;

=head1 NAME

Lexicon::Schema - Tangram storage schema for the Lexicon

=head1 SYNOPSIS

Tangram::Relational->deploy(Lexicon::Schema->schema, $dbh);

=head1 DESCRIPTION

This module returns the Tangram schema for the Lexicon database.
That's it.  Nothing else.  The only thing of interest is the object
types in storage.

=head2 OBJECT TYPES IN STORAGE

Lexicon
Lexicon::UniqueObject
Lexicon::NamedObject
Lexicon::Entry
Lexicon::Group

=head2 ADDING TO THE OBJECT TYPES

Call Lexicon::Schema->add_classes(@classes), where "@classes" is a
list of package names, which should all have Class::Tangram $schema
variables set.

=cut

use Tangram::Ref;
use Tangram::Schema;

use vars qw($db_schema @classes @languages %classes $DEBUG);

BEGIN { $DEBUG = 0 };
sub mutter { $DEBUG && print STDERR __PACKAGE__.": <D> @_\n" };
sub say { print STDERR __PACKAGE__.": @_\n" };

sub _schema {

    my $schema = { classes => [ ] };

    for my $class ( @classes ) {
	no strict 'refs';
	my $class_schema = ${"${class}::schema"}
	    or die "${class}::schema undefined!";

	push @{$schema->{classes}}, $class => $class_schema;
    }

    $db_schema = Tangram::Schema->new($schema);

}

sub schema {
    return $db_schema || _schema();
}

sub zap_schema {
    $db_schema = undef;
}

sub add_classes {
    ( ref $_[0] || ($_[0] eq __PACKAGE__) )
	&& shift;

    mutter "Been asked to add classes `@_'";

    for my $class ( @_ ) {
	unless ($classes{$class}++) {
	    push @classes, $class;
	    mutter "Trying to `use $class;'";
	    eval "use $class";
	    die "$@ using $class" if $@;
	} else {
	    mutter "Skipping - $class - already loaded";
	}
    }
    mutter "\@classes = @classes";
}

sub languages {
    return keys %{{ map {$_ => 1} @languages }};
}

sub add_languages {
    ( ref $_[0] || ($_[0] eq __PACKAGE__) )
	&& shift;

    mutter "Been asked to add languages `@_'";
    push @languages, @_;

    for my $lang ( @_ ) {
	if ($classes{"Lexicon::Entry::".$lang}++) {
	    mutter "Not adding lang $lang - already there";
	} else {
	    push @classes, "Lexicon::Entry::$lang";
	    eval "use Lexicon::Entry::$lang";
	    if ( $@ ) {
		# no package for this language - go create one
		mutter "Creating Lexicon::Entry::$lang";
		eval (";package Lexicon::Entry::$lang"
		      .";use Lexicon::Entry"
		      .";use overload"
		      .";use vars qw(\$schema \@ISA)"
		      .";\@ISA = qw(Lexicon::Entry)"
		      .";\$schema={table=>'${lang}_entries',"
		      ."fields=>{},bases=>[qw(Lexicon::Entry)]};");
		$@ && die "Internal error compiling language $lang module";
	    } else {
		mutter "using Lexicon::Entry::$lang";
	    }
	}
    }
    mutter "\@classes = @classes";
}

BEGIN {
    use Pod::Constants
	'OBJECT TYPES IN STORAGE' => sub {
	    my @builtin = /(\S+)/g;

	    for my $class (@builtin) {
		if ( $classes{$class}++ < 1 ) {
		    push @classes, $class;
		    mutter "BEGIN: using $class";
		    eval "use $class";
		    die $@ if $@;
		} else {
		    mutter "BEGIN: skipping $class";
		}
	    }
	};

};

1;
