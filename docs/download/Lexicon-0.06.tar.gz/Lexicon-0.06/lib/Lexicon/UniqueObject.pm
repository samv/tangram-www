#!/usr/bin/perl -w

package Lexicon::UniqueObject;

use strict;
use Carp;

=head1 NAME

Lexicon::UniqueObject - Common base class for all unique objects in the lexicon

=head1 SYNOPSIS

 # programming UniqueObject derived types:
 package Lexicon::SomeThing
 use base qw(Lexicon::UniqueObject);

 $schema = { fields => { ... },
             bases => [qw[Lexicon::UniqueObject]] };

 # objects must implement this method
 sub merge {
     my ($self, $in_memory) = (@_);
     die if ($self->{name} ne $in_memory->{name});

     if ($self->{foo} > $in_memory->{foo}) {
	 # storage copy (self) is better, but get bar from
	 # memory if not in storage
         $self->{bar} ||= $in_memory->{bar};

     } else {

	 # memory copy is better, overwrite current object,
	 # except baz
	 %$self = (baz => $self->{baz}, %$in_memory);
     }
 }

 # Using UniqueObject derived types:
 my $foo = Lexicon::SomeThing->new(name => "SomeName");

 # query - search only, never insert
 $foo = Lexicon->query($foo);

 # like query, but inserts if not found.
 $foo = Lexicon->ratify($foo);

=head1 DESCRIPTION

UniqueObject provides a standard way of taking two objects - one in
memory, and one from storage, and "merging" them so that all the
important fields from one object are kept in the other.

UniqueObject defines an I<interface>, which is an OO concept not
directly supported by Perl.  Instead, you must use inheritance and
define at least the "select_func" method.

=cut

use Class::Tangram;
use vars qw($schema @ISA);
@ISA = qw(Class::Tangram);

$schema =
{
 abstract => 1,
 fields => {},
 table => "symbols",
 id => 2,
};

use overload
    '0+' => \&as_ptr,
    '+' => \&add,
    'bool' => sub { 1 },
    fallback => 1;

=head1 FUNCTIONS

=head2 $self->merge($new_obj)

Take any interesting information out of the object $new_obj
(presumably a non-persistent object) and write it into $self

=cut

sub merge {
    my $self = shift;
    my $obj = shift;
    croak "invocant not ".__PACKAGE__
	unless UNIVERSAL::isa($self,__PACKAGE__);
    croak "1st arg not ".__PACKAGE__
	unless UNIVERSAL::isa($obj,__PACKAGE__);
    croak ("Attempt to merge a ".(ref $self)." with a ".(ref $obj))
	unless ( ref $self eq ref $obj );

    # don't attempt to merge anything; the subclass method will do
    # that.

    # If they don't, they will just get the object from storage with
    # nothing of the new one.
}

=head2 $self->select_func($storage)

Returns a Tangram select expression that will match this object in
storage.

Return:

   1 - a Tangram::Remote object
   2 - Tangram Filter

=head2 Class->select_func($storage, @some_args)

An alternate method for the above, that takes C<@some_args> and builds
a select expression.  The exact format of C<@some_args> is
class-dependant, but will likely contain key identification elements.

=cut

sub select_func {
    my $invocant = shift;
    die ("Attempt to select a unique object from storage, but "
	 .(ref($invocant)||$invocant)."->select_func() is not "
	 ."defined");
}

=head2 add (overloaded `+' operator)

Sometimes, you need a unique identifier for an object.  Adding 0 to it
has been a long standing trick to getting one for Perl objects,
however this sucks with `use overload'.  The first time this function
is called, this function issues a serial number, chucks it in
$self->{_serial}, and returns that instead.  Subsequent calls will get
the same number, so it has the same properties as adding 0.

=cut

use vars qw($SERIAL_NUMBER);

sub add {
    my ($self, $other, $reversed) = (@_);

    if ( defined $other and $other == 0 ) {
	return ($self->{_serial} ||= (++$SERIAL_NUMBER));
    }
}


=head2 as_ptr (overloaded "0+" operator)

For conversion to an integer.  dummy function.

=cut

sub as_ptr {
    my ($self) = shift;

    return ($self->{_serial} ||= (++$SERIAL_NUMBER));
}

"This is the" __END__, beautiful friend.

=head1 SEE ALSO

L<Tangram::Storage>, L<Lexicon>

=cut
