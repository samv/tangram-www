package Lexicon::Group;

use Date::Manip qw(ParseDate);
use Tangram::Set;
use Tangram::Scalar;
use Tangram::DMDateTime;

use vars qw($schema @ISA);
use Lexicon::NamedObject;
@ISA = qw(Lexicon::NamedObject);

$schema = {
	   table => "Groups",
	   fields =>
	   { dmdatetime => [ qw(created) ],
	     set       => {
			   members => {
				       class => "Lexicon::Entry",
				       coll => "group_id",
				       table => "entry_members",
				      },
			  },
	   },
	   bases => [qw(Lexicon::NamedObject)],
	   id => 6,
	  };

__PACKAGE__->set_init_default(created => sub { ParseDate "now" });

2;
