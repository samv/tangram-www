#!/usr/bin/perl -w

use strict;
package Lexicon::Entry::Latin;
use Lexicon::Entry;
use vars qw($schema @ISA);
@ISA = qw(Lexicon::Entry);

$schema = { fields => {}, bases => [ qw(Lexicon::Entry) ] };

=head1 NAME

Lexcion::Entry::Latin - A Latin lexicon entry

=head1 SYNOPSIS

=head1 DESCRIPTION

This module is mostly a provider of common functions applicable to
Latin languages.

=cut

=head1 FUNCTIONS

=head2 [uc,word], [lc,word], [cap,word]

Returns the UPPER CASE, lower case or Capitalisation of the
argument(s).

=cut

# FIXME - � -> �, etc
sub uc { my $self = shift; return map { uc } @_; }
sub lc { my $self = shift; return map { lc } @_; }
sub cap {
    my $self=shift;
    return map { s/\b([a-z])(\w*)/CORE::uc($1).CORE::lc($2)/eg; $_ }
	@_;
}

1;

__END__

=head1 BUGS/TODO

Should uc/lc be a Latin thing or an encoding-specific thing?

This module needs some more iocus latinus.  I only speak piggus
latinus maximus.

=head1 AUTHOR

Sam Vilain, <enki@snowcra.sh>

=cut

