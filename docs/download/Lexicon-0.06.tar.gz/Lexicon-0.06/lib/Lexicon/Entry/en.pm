#!/usr/bin/perl -w

use strict;
package Lexicon::Entry::en;

use Lexicon::Entry::Latin;
use vars qw($schema @ISA);
@ISA = qw(Lexicon::Entry::Latin);

use overload;
$schema = { fields => {}, bases => [ qw(Lexicon::Entry::Latin) ] };

=head1 NAME

Lexicon::Entry::en - Queen's English Lexicon entries

=head1 SYNOPSIS

$entry->text();

=head1 DESCRIPTION

A Lexicon::Entry::en represents a lexicon entry that is in the mother
tongue of England.  For bastard dialects such as Amarikin, Sowt
Affrikaan, Arstraaliun or Nuew Zeerlund, those would be found under
Lexicon::Entry::en_XX, where XX is either US, ZA, AU or NZ,
respectively.

One uses the functions in this module for preparing messages for the
working and middle class - that is, messages that one does not get
one's servants to read to them or one reads from a book.

Messages that will be requiring a pluralisation, for instance, will be
the sort of thing that you use this module for.

=head1 LANGUAGE FUNCTIONS

Without further ado, then, here is the list.

=head2 [&plura,N,word]

=head2 [&plura,N,singular,plural]

Returns the plural of "word", if "N" is not 1.  Otherwise, returns the
singular form of "word".

This module SHOULD do the right thing with, eg "beauty" -> "beauties",
but you know English, it's full of exceptions.  If you find one it
doesn't do correctly, please LET ME KNOW.

The returned word will be in lower case.  If you need to perform
capitalisation mutation on the word, prepend the appropriate
capitalisation function from Lexicon::Entry::Latin.  eg
[&uc,&plura,axis,4] returns AXES.

This function is fairly expensive the first time you call it for a
given noun.

=cut

my %cache =
    (
     # words that don't change
     # leave out "perch", because there are two pluralisations
     (map { $_ => $_ } (qw(sheep deer cod offspring trout dice))),

     # simple "es" that don't fit pattern matching very well
     # The bane of Dan Quayle :-)
     (map { $_ => $_."es" }
      (qw(potato veto embargo tomato torpedo volcano))),

     # some exceptions imported from Latin
     (map { $_ => (substr($_, 0, -2) . "a") }
      (qw(addendum bacterium curriculum datum erratum
	  medium memorandum ovum stratum symposium corpus
	  genus criterion phenomenon automaton))),
     (map { $_ => (substr($_, 0, -2) . "i") }
      (qw(alumnus bacillus focus fungus nucleus radius
	  stimulus terminus
	  ))),
     (map { $_ => $_."e" }
      (qw(alga amoeba antenna formula
	  larva nebula vertebra))),
     (map { $_ => (substr($_, 0, -2) . "ices") }
      (qw(apex appendix cervix index matrix vortex))),
     (map { $_ => (substr($_, 0, -2) . "es") }
      (qw(analysis axis basis crisis diagnosis emphasis hypothesis
	  neurosis oasis parenthesis synopsis thesis
	  ))),

     # some old English words
     qw(
	ox       oxen
	die      dice
	),

     # Italian
     qw(
        libretto libretti
	tempo    tempi
	virtuoso virtuosi
       ),

     # Hebrew
     qw(
	cherub   cherubim
	seraph   seraphim
	),

     # Greek
     qw(
	schema   schemata
       ),

    );

sub plura {
    my $self = shift;
    my $count = shift;
    my $word = lc(shift);
    my $plural = shift;

    if ( $count == 1 ) {
	return $word;
    } elsif ( defined $plural ) {
	return $plural;
    } else {

	# print STDERR "Plural of \"$word\" is \"";

	(exists $cache{$word}) && do {
	    # print STDERR "$cache{$word}\"\n";
	    return $cache{$word};
	};

	$cache{$word} ||= do { 
	    #study $word;

	# words ending in y get -ies (except proper nouns; bugger :)
        ($word =~ s/([^aeiou])y$/${1}ies/)

	# or sometimes just s
     or ($word =~ s/([aeiou])y$/${1}ys/)

        # ch, x usually gets -es
     or ($word =~ s/(ch|x|s)$/${1}es/)

        # words like "calf", "elf", "hoof", etc.  Perhaps the [oliar]
	# group should just be "."
     or ($word =~ s/([aeuioy][oliaer])f$/${1}ves/)

	# Other silly words - included as regexes because they are
	# likely to be used as suffixes
     or ($word =~ s/child$/children/)
     or ($word =~ s/tooth$/teeth/)
     or ($word =~ s/man$/men/)
     or ($word =~ s/goose$/geese/)
     or ($word =~ s/([lm])ouse$/${1}ice/)
     or ($word =~ s/hero$/heroes/)
     or ($word =~ s/foot$/feet/)

        # bugger it, just chunk an s on the end
     or ($word =~ s/$/s/);

#	    print STDERR "$word\"\n";
	$word;
    };

	return $word;
    }
}

=head1 LINGUISTAHOLICS ANONYMOUS

Many modules are out there on CPAN that do linguistic stuff.

By simply "using" them in the space of a language namespace, you let
people use all of the functions that module exports

=cut

=head2 IMPORTED FROM Lingua::EN::Numbers

=over

=item [number,N]

"One", "Two", "Three point seven", etc

=back

=cut

# fore!
BEGIN{my$M="Lingua::EN::Numbers";local($^W)=0;eval"use $M;sub number{"
."shift;($M->new((shift)+0))->get_string}"};

=head2 IMPORTED FROM Lingua::EN::Numbers::Ordinate

=over

=item [ordinate,N]

Returns the ordinate of N.  ie, 1st, 2nd, 3rd, 42nd, etc.

=item [th,N]

Synonym for the above

=item [ordsuf,N]

Just the ordinate suffix.  ie "st", "nd", etc.

=back

=cut

# See, much easier :-)
{
    package DontPolluteMyBloodyNamespace;
    use Lingua::EN::Numbers::Ordinate qw(th);
}

sub ordinate # heh, reminds me of `man date'
           { shift; return &Lingua::EN::Numbers::Ordinate::ordinate(@_); }
sub th     { shift; return &Lingua::EN::Numbers::Ordinate::th(@_); }
sub ordsuf { shift; return &Lingua::EN::Numbers::Ordinate::ordsuf(@_); }

1;

__END__

=head1 BUGS/TODO

some of these functions apply to languages other than English.

some rules within a function apply to languages other than English.

=head1 AUTHOR

Sam Vilain, <enki@snowcra.sh>

=cut
