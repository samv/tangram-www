#!/usr/bin/perl -w

use strict;

package Lexicon::Entry;

# debug stuff.
sub debug { print STDERR __PACKAGE__.": @_\n" }
BEGIN {
    my $DEBUG = 0;
    no strict;
    # who needs "eval" to re-define functions?
    *{__PACKAGE__.::mutter} = (($DEBUG>0) ? \&debug : sub { });
    *{__PACKAGE__.::mumble} = (($DEBUG>1) ? \&debug : sub { });
}

=head1 NAME

Lexicon::Entry - An entry in the Lexicon

=head1 SYNOPSIS

 use Lexicon::Entry _ => "your_script_name_here";

 print _("Hello, world");

 # For over-complicating things; _RegistrationCost is
 # defined/loaded by some Lexicon::Entry::Subclass, or
 # present in the Lexicon Database.
 print _('_RegistrationCost');

=head1 DESCRIPTION

Lexicon Entries are the fundamental building block of the Lexicon.
They have several attributes:

=over

=item name

An Entry has a name.  This will be either a symbolic tag (starting
with _) or some bare text in the same language as the entry.

=item function

An Entry has a function.  This is normally a piece of text, but can
also be a perl function, or something vaguely maketext-ish (see
L<Locale::Maketext::TPJ13> for a historical discourse into why this is
necessary).

This is compiled to an internal attribute "C<_function>", which is a
closure.

If the function is a piece of text, the closure is merely a sub that
returns that piece of text.

If the function starts with "C<#!perl>", the perl should either return
a closure, or a piece of text.  If it returns a piece of text, that
text is returned every time the entry is printed.  If it returns a
closure, that closure is called when the C<-E<gt>text(@args)> method
is called, with C<@args> as C<@_[1..$#args+1]> ($_[0] is a reference
to the actual Lexicon::Entry object).

A shorthand exists for creating the vast majority of entries.  This is
derived from Locale::Maketext's format, but differs slightly.  Its
format is covered in the section on "ZANY BRACKETY PERLY SHORTHAND",
below.

=item quality

The "quality" field is intended to represent the level of review of
lexicon entries.  Entries default to a quality of 1.  If there are
duplicate entries of the same name, but different qualities, then the
highest quality entry is returned.

=for item groups

A set of Lexicon::Grouping objects.  Each Lexicon::Grouping object
links one Lexicon::Entry with one Lexicon::Group.

NOTE: currently this isn't implemented very thoroughly.  To be fixed
shortly.

=item modified

This is the time that the object was modified.  It is in Date::Manip
internal format; see L<Date::Manip> for how to convert it to other
formats.

=item args

This is an ARRAY ref.  When the C<-E<gt>text(@args)> function is
called, everything in this array is prepended to C<@args> (after
C<$self>) and the function is called.

=item whence

This variable is set when this entry is created; its contents will
probably be the source file name or package where the object was first
created; in theory, whenever this entry is used, it will make sure
that there is an entry in the "groups" field for that "whence".  More
on this in a later release.

=item lexicon

An optional reference to the lexicon that this entry came from.  This
is set by the lexicon when entries are returned, and is used for
expanding references to entries from within other entries (see
L<Including other lexicon entries>)

=back

=head2 ZANY BRACKETY PERLY SHORTHAND

Learn by example:

=over

=item "Hello, world"

 sub { "Hello, world" }

=item "Hello, [_1]"

 sub { "Hello, $_[1]" }

=item "Hello, [_who]"

 sub { "Hello, $_[1]->{who}" }

=item "[_1] [&plura,_1,egg]"

 sub { "$_[1] ".$self->plura($_[1], "egg") }

=item "[_1] [&uc,&plura,_1,egg]"

 sub { "$_[1] ".$self->uc($self->plura($_[1], "egg")) }

=item "[_1] [&uc(,&plura,_1,egg),eggs]"

 sub {
    "$_[1] ".$self->uc($self->plura($_[1], "egg"),
                       "eggs")
 }

=item "[_1] [&uc,&plura,_1,egg,eggs]"

 sub {
    "$_[1] ".$self->uc($self->plura($_[1], "egg", "eggs"))
 }

=back

Note that because these functions are called as methods of the entry,
they should be declared in those scopes.

=head2 Including other lexicon entries

The following syntax is used for including lexicon entries from within
other lexicon entries:

  [&_entry,args]

Where C<_entry> is the name of the lexicon entry to include, and
C<args> are its arguments.

Note that if your arguments were passed to you by name, then you can
pass that structure down to the included lexicon entry by making
C<args> simply C<_1>.

For example, given the following function called C<_rizla>:

  You have [_remaining] of your [_colour] skins remaining.

You could define a function C<_tinny_stats> like this:

  Your tinny is [sprintf,%.1f,percentage]% full, and
  [&lc,&rizla,_1].

The following:

  _(_tinny_stats => { remaining => 15,
                      colour => "Blue",
                      percentage => 78.256 })

Would evaluate to:

  Your tinny is 78.23% full, and you have 15 of your blue
  skins remaining.

Currently, for this to work, the entry must have been retrieved from a
still open Lexicon that is able to look up the included entry.  This
lookup happens once the first time a function is used in a given
language.

This is implemented with a technique similar to function autoloading;
when the entry compiler sees a function name that it doesn't think it
C<-E<gt>can>, then it calls the C<autoload> function.

It stores references to these cached entries in a package global hash
C<%Lexicon::Entry::lang::entries>, which can be emptied with
the C<Lexicon::Entry::lang::dump()> function.

=cut

use vars qw(%entries);

=head2 FORMATTING WITHIN LEXICON ENTRIES

Sometimes, you want to highlight a word in the middle of a sentence.
Do this with XML if you can.  But the module doesn't enforce anything,
even the encoding, so feel free to make the function return whatever
you like.

=cut

use Tangram::Scalar;
use Tangram::Set;
use Tangram::DMDateTime;
use Tangram::RawDateTime;
use Carp;
use Date::Manip;
use I18N::LangTags qw(is_language_tag);

use Lexicon::NamedObject;
use vars qw($schema @ISA);
@ISA=qw(Lexicon::NamedObject);

$schema = {
	   bases => [ qw(Lexicon::NamedObject) ],
	   id => 5,
	   fields =>
	   {
	    string     => {
			   # the name/id - index this column!
			   #name => undef,

			   # "function" may be a piece of text, or a
			   # maketext-like string.
			   function => { sql => "TEXT" },
			  },
	    int        => {
			   # "quality" - an indicator of how well this
			   # entry has been translated
			   quality =>
			   {
			    sql => 'int(3) default 0',
			    init_default => 1,
			   },
			  },
	    #iset       => {
			   #groups => {
				      #class => "Lexicon::Grouping",
				      #coll => "entry_id",
				     #},
			  #},
	    dmdatetime => [ qw(modified) ],
	    transient => {
			  map {$_ => undef}
			  qw(args whence lexicon)
			 },
	   },
	   table => "Entry",
	  };

__PACKAGE__->set_init_default(modified => sub { ParseDate "now" });

=head1 METHODS

=head2 import(_ => "myscript")

Defines the initialisation features of the "_" function,
effectively noting to the compiler the default language to
be used for messages in this source file, and the "whence"
value, later used for categorising and browsing messages.

=cut

use Data::Dumper;

sub import {
    my $class = shift;
    my $ref = $class->can("lookup");
    my $source_info = bless { }, "Lexicon::Entry::_source_info";

    mutter "Importing $class to ".caller();

    # try to guess the source file of the caller
    if (caller ne "main") {
	(my $module = caller().".pm") =~ s|::|/|g;

	if ( $source_info->{file_name} = $INC{$module}) {
	    ($source_info->{caller} = caller());
	}
    }

    mumble "Source file is ".
	($source_info->{file_name} ||= ($source_info->{caller} = $0));

    no strict;
    local ($^W) = 0;

    $source_info->{whence} =
	(${caller().::NAME} || $source_info->{caller});

    # this avoids a warning with 5.005 (Name
    # "Lexicon::Entry::en::NAME" used only once: possible typo...)
    my $arse = ${caller().::NAME};

    while ( my $arg = shift ) {

	if ( $arg eq "_") {
	    my $whence = shift || $source_info->{whence};
	    $whence =~ s!^.*/!!;

	    mutter "Polluting ".caller()."::_ as requested, $class/$whence";
	    #print STDERR Dumper($source_info);
	    local ($^W) = 0;
	    *{caller()."::_"} = sub {
		&$ref($class, -whence => $whence, @_ );
	    };
	} else {
	    die "huh? $arg? ".join(", ", map { "\'$_\'" } @_)."?";
	};
    }
}

=head2 lookup([$Lexicon], [-whence => $whence], $name, @args)

Lookup looks up a lexicon entry in the Lexicon, or just returns a new
Lexicon::Entry object if the lexicon is not open.

=cut

sub lookup {

    # First argument: optional, Class
    my $class;
    if ( UNIVERSAL::isa($_[0], __PACKAGE__) ) {
	$class = shift;
    }
    mumble "looking something up in language $class";

    # Second; lexicon
    my ($lexicon);
    if ( UNIVERSAL::isa($_[0], "Lexicon") ) {
	$lexicon = shift;
    } elsif ( $lexicon = $Lexicon::Default ) {  # nasty
	mumble "doing lookup in default lexicon";
    } else {
	mumble "no lexicon open, none will be looked up in";
    }

    mumble "returning an answer in language ".$lexicon->lang()
	if $lexicon;

    # "whence"
    my $whence;
    if ( UNIVERSAL::isa($_[0], "Lexicon::Group" )) {
	$whence = shift;
    } else {
	if ( $_[0] eq "-whence" ) { shift; $whence = shift; }
	$whence ||= caller();
	if ( $whence =~ /^Lexicon::/ ) {
	    # not allowed!
	    $whence = undef;
	}
	$whence ||= $0;
    }

    mumble "this entry comes from ".(defined $whence?$whence:"[undef]");

    # next arg
    my $name = shift;

    # remaining arguments on the stack go to the ->text() call
    (my $argstack, @_) = ([ @_ ]);

    my $entry = $class->new( name => $name,
			     args => $argstack,
			     whence => $whence );

    if ( $lexicon ) {

	if ( my $obj = $lexicon->lookup($entry) ) {

	    # found in the lexicon, return it
	    mutter "Returning an entry in language ".$obj->lang;
	    mutter "The entry is \"$obj\"";
	    return $obj;
	} else {
	    die "Could not find entry ".$entry->name." in lexicon";
	}

    } else {
	mutter "not performing a lookup";
	# no lexicon loaded - none looked up in - just return as is
	return $entry;
    }

}

=head2 set_*($new_value), get_*

These functions are inherited from Class::Tangram.  See
L<Class::Tangram> for full details.

For example,

    $entry->set_args([ "world" ]);
    print Dumper $entry->get_args;
    print Dumper $entry->args;      # same thing

    print Dumper $entry->quality;

=cut

=head2 set_function

Set the function of the entry.  Automatically updates the "modified"
field of the Entry.

=cut

sub set_function {
    my $self = shift;

    $self->{function} = shift;
    $self->set_modified(ParseDate("now"));

}

=head2 lang

Returns the language of the entry.  This is a default function that
just returns a munged "C<ref $self>", so you'll only have to override
this function in classes you place outside the C<Lexicon::Entry::>
namespace (by the way, please take that as an open invitation to
invade the namespace with a module for your favourite language).

=cut

sub lang {
    UNIVERSAL::isa(my $self = shift, "Lexicon::Entry")
	    or croak "ribbit";

    my $class = ref $self or die "not a reference";
    return "nil" if ($class eq __PACKAGE__);
    $class =~ s/Lexicon::Entry:://;
    $class =~ s/(::|_)/-/;
#define $class $language
    carp ("The class `".ref($self)."' has to convert to a valid "
	  ."RFC3066-style language tag, not `$class'.")
	unless (is_language_tag($class));

    return $class;
}

=head2 text(@args)

Evaluate the text.

If the entry is a function, then this will simply call it with the
given arguments.

If the entry is a function with C<_1> placeholders, then C<_1> is
C<$args[0]>, C<_2> is C<$args[1]>, etc.

If the entry is a function with C<_name> placeholders, then
C<$args[0]> is interpreted as a HASH ref, and is filled out as you'd
expect (ie, C<_name> would be replaced by C<$args[0]->{name}>)

=cut

sub text {
    my $self = shift;

    $self->compile->($self, @{$self->args||[]}, @_);

}

=head2 compile

Convert the "C<function>" member into "C<_function>", or die.

=cut

sub compile {
    my $self = shift;

    $self->{_function} && return $self->{_function};

    # If the function is not defined, and the name doesn't start with
    # an underscore, automatically build the function.
    # FIXME - argh, this might be the wrong thing with "query" entries
    if ( !$self->{function} ) {
	if ( my ($id) = $self->{name} =~ m/^_(.*)$/ ) {
	    if ( my $func = $self->can($id) ) {
		$self->{_function} = $func;
	    } else {
		die "Tried to print a tag with no function - _$id";
	    }
	} else {
	    $self->{function} = $self->{name};
	}
    }

    # a perl block - just eval
    if ( $self->{function} =~ m<^#!perl>) {

	(my $code = $self->{function}) =~ s/^#!perl//;
	my $result = eval $code;
	die ("Eval error - \"$@\" - compiling function for "
	     .$self->{name}."/".ref($self)) if $@;

	# they should return a closure or a string
	if ( ref $result eq "CODE" ) {
	    $self->{_function} = $result;
		#my $self = shift;
		#unshift @_, $self;
		#goto $result;     # goto rocks
	    #}
	} elsif ( ref $result ) {
	    # er ... what?
	    die ("Function for $self->{name}/".ref($self)
		 ." returned a ref ".ref($result));
	} else {
	    # string .. ok
	    $self->{_function} = sub { $result };
	}

    } else {

	# compile a Maketext-like string into a code ref.

	# @list is a list of things to do; it is a list of closures.
	my @list;

	# FIXME - UTF8 (fixed itself!)
	while ( $self->{function} =~  # Iterate over chunks.
		m<\G(?:  ([^\~\[\]]+) # non-~[] stuff
		    |    ~(.)         # ~[, ~], ~~, ~other
		    |    \[([^]]*)\]  # [ in a group
		    )
		 >xgsc ) {

	    my ($normal_text, $esc, $command) = ($1, $2, $3);
	    $normal_text = $esc unless defined $normal_text;

	    # hopefully this is flexible enough, for a quick hack.
	    # Hey, it's less lines of code than Maketext's and doesn't
	    # even use eval.  It uses one hell of a lot of closures,
	    # though :-)
	    if ( $command ) {

		# $list holds which argument stack the current item is
		# going on.  Put closures only on here.
		my $list = \@list;

		# if we come across parantheses, create a new list and
		# save a pointer to the old one
		my @stack;

		# iterate over each item in the bracketed list
		for my $item ( split /\s*,\s*/, $command ) {

		    # placing a parantheses at the end of an item
		    # closes a function (optional)
		    my $pop;
		    if ( $item =~ s/\)$// ) {
			$pop = 1;
		    }

		    # variable interpolations - _N, _hashkey
		    if ( $item =~ m/^_(\d+)$/) {
			my $num = $1;
			push @$list, sub { $_[$num] };

		    } elsif ( $item =~ m/^_(\w+)$/) {
			my $var = $1;
			push @$list, sub { $_[1]->{$var} };

		    } elsif ( my ($func) =
			      ($item =~ m/^&(\w+)\(?$/)) {

			# must be a function, any further arguments in
			# this bracket go onto this function's list
			push @stack, $list;
			my $newlist = [];

			# If there is no function called $func in our
			# namespace, then try and load a lexicon entry
			# with that name with underscore prepended.

			unless ( $self->can($func) ) {
			    $self->autoload($func);

			}

			push @$list, sub {
			    # what's that sound I hear?  "thunk"?
			    $_[0]->$func(map {$_->(@_)} @$newlist);
			};
			$list = $newlist;

		    } else {
			# treat as a string literal
			push @$list, sub { $item };
		    }

		    # if they close a function, pop the stack
		    if ( $pop ) {
			$list = pop @stack
			    or die ("too many closing parantheses "
				    ."within [] for $self->{name}/"
				    .ref($self));
		    };
		}
	    } else {
		push @list, $normal_text;
	    }
	}

	# did we match the whole string?
	if ( pos $self->{function} != length $self->{function} ) {
	    die "Function for $self->{name}".ref($self)." didn't parse";
	}

	# And that's all there is to it.
	$self->{_function} = sub {
	    local ($^W) = 0;  #don't moan
	    join "", map {
		if (ref $_) {
		    $_->(@_);
		} else {
		    $_ || ""
		}
	    } @list;
	};
    }

    return $self->{_function};
}

=head2 recompile

recompiles the function

=cut

sub recompile {
    delete $_[0]->{_function};
    goto &compile;
}

=head2 autoload($func[, $force])

Look up "_$func" in the lexicon, and insert into our namespace, making
the function available for use.

Returns a CODE reference to the compiled function.

=cut

sub autoload {
    my $self = shift;
    my $func = shift;
    confess "autoload attempted, but lexicon not known for `$func'"
	unless $self->lexicon;
    $func =~ m/^(\w+)$/
	or confess "autoload function contains illegal characters";

    my $force = shift;

    # If already there, don't recompile
    if ( not $force and my $ref = $self->can($func) ) {
	return $ref;
    } else {
	no strict "refs";

	# create a "query object" - see L<Lexicon::UniqueObject>
	my $wanted = (ref $self)->new(name => "_$func");

	# Compile the loaded function and put it into our package
	*{$func} = (
		    # Query the lexicon with the query object
		    $entries{$func} = $self->lexicon->query($wanted)
		   )
	    ->compile();

    }

}

=head2 dump([@func])

Dumps the cached included functions.  If C<@func> is empty, then ALL
functions are dumped.

An assumption is that the object that calls this has connected an open
lexicon capable of performing lookups 

=cut

sub dump {
    my $self = shift;

    my @funcs = (@_) or keys %entries;
    no strict 'refs';

    for my $func ( @funcs ) {
	# delete its entry from the package's cache, and redefine its
	# function with a code reference that will re-load itself.
	if ( my $victim = delete $entries{$func} ) {
	    *{$victim} = sub {
		goto scalar $self->autoload($func);
	    };
	}
    }

}


=head1 Overloaded operations

Certain operations have been overloaded.  Here they are.

=cut

use overload
    '""' => \&as_string,
    cmp => \&compare,
    fallback => 1;

=head2 as_string (overloaded `""' operator)

The stringify function.  Basically, prints out the entry.  You don't
get a chance to give this any arguments, so you better have already
set them with C<$entry->set_args([ @parameters ]);>

If you have a Lexicon loaded, and the language is not the right
language, the entry will be looked up in the Lexicon before
proceeding.

=cut

sub as_string {
    my $self = shift;

    $self->{args} ||= [];

    if ( $Lexicon::Default and
	 $self->lang ne $Lexicon::Default->lang ) {
	#kill 2, $$;
	print STDERR "Looking up a ".$Lexicon::Default->lang
	    ." from a ".$self->lang."\n";
	$Lexicon::Default->lookup($self)->text();
    } else {
	$self->text();
    }
}

=head2 compare (overloaded `cmp' operator)

Compares the `quality' field of the two given arguments; for use with
sorting.

=cut

sub compare {
    my $a = shift;
    my $b = shift;

    if ( UNIVERSAL::isa($a, __PACKAGE__) ) {
	if ( UNIVERSAL::isa($b, __PACKAGE__) ) {
	    $b->{quality} <=> $a->{quality};
	} else {
	    return $a->as_string cmp $b
	}
    } else {
	if ( UNIVERSAL::isa($b, __PACKAGE__) ) {
	    return $a cmp $b->as_string;
	} else {
	    die "impossible condition reached";
	}
    }
}


=head1 Inherited interfaces

Lexicon::Entry inherits the Lexicon::NamedObject interface, and
implements the "merge" function, as below:

=head2 $self->merge($obj)

Merges two Lexicon::Entry objects; $self should be fresh from storage,
and $obj the same object in memory.

This function copies across the "args" attribute, and also the
internal compiled code ref (if the functions that they are built from
are the same).

=cut

sub merge {
    my $self = shift;
    my $other = shift;

    # copy across the args
    ($self->{args} = [ @{ $other->{args} } ])
	if (ref $other->{args} eq "ARRAY");

    # "Use of uninitialized value in string eq" - who cares
    local ($^W) = 0;

    # copy across _function
    $self->{_function} = $other->{_function}
	if ($self->{function} eq $other->{function});

}

=head2 sprintf


=cut

use Data::Dumper;
sub sprintf {
    shift;
    my $a = CORE::sprintf($_[0], @_[1..$#_]);
}

2.718281828459045235360287471352662497757247093699959574966967627724;
