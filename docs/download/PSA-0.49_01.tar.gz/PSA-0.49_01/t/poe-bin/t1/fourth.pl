
my $psa = shift;

print "ok 6\n";
