
my $psa = shift;

Test::More::pass("Got to whassap");

$psa->yield("forkit");
