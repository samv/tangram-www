
my $psa = shift;

Test::More::pass($psa->heap->{name}.": got to yoyo");


