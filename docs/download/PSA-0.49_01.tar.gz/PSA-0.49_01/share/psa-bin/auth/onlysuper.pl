
my $psa = shift;

return $psa->run("/auth/only.pl", "onlysuper.pl");
