
use lib "t";
use DBConfig;
use TestNeeds qw(Test::More
		 Class::Accessor::Assert
		 Time::Piece);
use MusicStore;

1;
