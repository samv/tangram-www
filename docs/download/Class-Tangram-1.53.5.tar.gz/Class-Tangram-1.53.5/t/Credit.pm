package Credit;

use NonsenseAndBalderdash;

1;
